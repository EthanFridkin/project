using System.Collections.ObjectModel;
using Battleship.Core.AI;
using Battleship.Core.Logic;
using Battleship.Core.Models;

namespace Project
{
    public partial class GamePage : ContentPage
    {
        private const int Cols = 10;
        private const int GameRows = 10;
        private const int ExtraRowsTop = 1;
        private const int ExtraRowsBottom = 7;
        private const int TotalRows = GameRows + ExtraRowsTop + ExtraRowsBottom;
        private const int SubStorageRows = 4;

        private double _cellSize;
        private double _boardStartY;
        private double _gameAreaTop;
        private double _gameAreaBottom;
        private double _boardWidth;
        private bool _boardsBuilt = false;

        private readonly Dictionary<View, Point> _playerOrigPos = new();
        private readonly Dictionary<View, Point> _lastTotal = new();

        private readonly Game _game;
        private readonly Player _humanPlayer;
        private readonly Player _aiPlayerModel;
        private readonly AIPlayer _ai;
        private readonly FirebaseService _firebase;
        private readonly bool _isGuest;
        private readonly bool _isMulti;
        private readonly bool _isGemini;
        private readonly GeminiService _gemini;
        private readonly string _opponentName;

        private enum GamePhase { Placement, Playing, Finished }
        private GamePhase _phase = GamePhase.Placement;

        private readonly Dictionary<View, Submarine> _subViewToModel = new();
        private readonly Dictionary<View, (int row, int col)> _aiCellToGrid = new();
        private readonly Dictionary<(int row, int col), Border> _playerCellViews = new();
        private readonly Dictionary<(int row, int col), Border> _aiCellViews = new();
        private readonly Dictionary<int, View> _playerSubViews = new();

        private const int TurnSeconds = 30;
        private int _timeLeft = TurnSeconds;
        private CancellationTokenSource? _cts;
        private CancellationTokenSource? _pollCts;
        private int _knownOpponentShots = 0;
        private int _knownChatMessages = 0;

        public GamePage(
            Player player,
            FirebaseService firebase,
            bool isGuest = false,
            bool isMulti = false,
            bool isGemini = false,
            string opponentName = "����")
        {
            InitializeComponent();
            _humanPlayer = player;
            _aiPlayerModel = new Player(0, opponentName);
            _game = new Game(1);
            _ai = new AIPlayer();
            _firebase = firebase;
            _isGuest = isGuest;
            _isMulti = isMulti;
            _isGemini = isGemini;
            _gemini = new GeminiService();
            _opponentName = opponentName;

            if (isMulti)
                AIAreaLabel.Text = opponentName;

            if (isGemini)
                AIAreaLabel.Text = "Gemini AI ??";

            this.SizeChanged += OnPageSizeChanged;
        }

        private void OnPageSizeChanged(object? sender, EventArgs e)
        {
            if (_boardsBuilt || this.Width <= 0 || this.Height <= 0) return;
            _boardsBuilt = true;

            double halfWidth = (this.Width - 3) / 2.0 - 20;
            _cellSize = Math.Floor(halfWidth / Cols);
            _boardWidth = _cellSize * Cols;

            _boardStartY = SubStorageRows * _cellSize + 8;
            _gameAreaTop = _boardStartY + ExtraRowsTop * _cellSize;
            _gameAreaBottom = _gameAreaTop + GameRows * _cellSize;

            BuildArea(PlayerArea, isPlayer: true);
            BuildArea(AIArea, isPlayer: false);

            double totalHeight = _boardStartY + TotalRows * _cellSize + 8;
            PlayerArea.HeightRequest = totalHeight;
            AIArea.HeightRequest = totalHeight;
            PlayerArea.WidthRequest = _boardWidth;
            AIArea.WidthRequest = _boardWidth;
        }

        private void BuildArea(AbsoluteLayout area, bool isPlayer)
        {
            area.Children.Clear();

            var gameColor = Color.FromArgb(isPlayer ? "#001F3F" : "#1F0000");
            var borderColor = Color.FromArgb(isPlayer ? "#00111F" : "#110000");
            var strokeColor = Color.FromArgb(isPlayer ? "#4488AA" : "#AA4444");
            var subColor = Color.FromArgb(isPlayer ? "#009ADA" : "#AA3333");

            // �� ��� Gemini � ��� ����� ���� �����
            if (!isPlayer && _isGemini)
            {
                gameColor = Color.FromArgb("#002200");
                borderColor = Color.FromArgb("#001100");
                strokeColor = Color.FromArgb("#44AA44");
                subColor = Color.FromArgb("#228833");
            }

            for (int row = 0; row < TotalRows; row++)
            {
                bool isGameRow = row >= ExtraRowsTop && row < ExtraRowsTop + GameRows;

                for (int col = 0; col < Cols; col++)
                {
                    var cell = new Border
                    {
                        BackgroundColor = isGameRow ? gameColor : borderColor,
                        Stroke = new SolidColorBrush(strokeColor),
                        StrokeThickness = 1,
                        StrokeShape = new Microsoft.Maui.Controls.Shapes.Rectangle(),
                        InputTransparent = isPlayer
                    };

                    AbsoluteLayout.SetLayoutBounds(cell, new Rect(
                        col * _cellSize,
                        _boardStartY + row * _cellSize,
                        _cellSize, _cellSize));

                    if (!isPlayer && isGameRow)
                    {
                        int capturedRow = row - ExtraRowsTop;
                        int capturedCol = col;
                        var capturedCell = cell;

                        _aiCellToGrid[cell] = (capturedRow, capturedCol);
                        _aiCellViews[(capturedRow, capturedCol)] = cell;

                        var tap = new TapGestureRecognizer();
                        tap.Tapped += (_, _) => OnAICellTapped(capturedCell, capturedRow, capturedCol);
                        cell.GestureRecognizers.Add(tap);
                    }

                    if (isPlayer && isGameRow)
                    {
                        int gameRow = row - ExtraRowsTop;
                        _playerCellViews[(gameRow, col)] = cell;
                    }

                    area.Children.Add(cell);
                }
            }

            if (!isPlayer) return;

            var fleet = FleetFactory.CreateDefaultFleet();
            double subX = 0, subY = 0;

            foreach (var s in fleet)
            {
                bool isHoriz = s.Orientation == Orientation.Horizontal;
                double w = isHoriz ? s.Length * _cellSize : _cellSize;
                double h = isHoriz ? _cellSize : s.Length * _cellSize;

                if (subX + w > _boardWidth && subX > 0)
                {
                    subX = 0;
                    subY += _cellSize + 2;
                }

                double clampedY = Math.Min(subY, _boardStartY - h - 2);

                var border = new Border
                {
                    BackgroundColor = subColor,
                    StrokeThickness = 0,
                    WidthRequest = w,
                    HeightRequest = h,
                    StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = 4 },
                    TranslationX = 0,
                    TranslationY = 0
                };

                var pos = new Point(subX, clampedY);
                AbsoluteLayout.SetLayoutBounds(border, new Rect(pos.X, pos.Y, w, h));

                _playerOrigPos[border] = pos;
                _subViewToModel[border] = s;
                _playerSubViews[s.SubmarineId] = border;

                var captured = border;
                var pan = new PanGestureRecognizer();
                pan.PanUpdated += (_, args) => OnSubmarinePan(captured, args);
                border.GestureRecognizers.Add(pan);

                area.Children.Add(border);
                subX += w + 4;
            }
        }

        private void OnSubmarinePan(View sub, PanUpdatedEventArgs e)
        {
            if (_phase != GamePhase.Placement) return;

            switch (e.StatusType)
            {
                case GestureStatus.Started:
                    _lastTotal[sub] = new Point(e.TotalX, e.TotalY);
                    break;

                case GestureStatus.Running:
                    {
                        var last = _lastTotal.GetValueOrDefault(sub, Point.Zero);
                        double dx = e.TotalX - last.X;
                        double dy = e.TotalY - last.Y;
                        _lastTotal[sub] = new Point(e.TotalX, e.TotalY);

                        var bounds = AbsoluteLayout.GetLayoutBounds(sub);
                        double absX = bounds.X + sub.TranslationX + dx;
                        double absY = bounds.Y + sub.TranslationY + dy;

                        absX = Math.Max(0, Math.Min(absX, _boardWidth - bounds.Width));
                        absY = Math.Max(0, Math.Min(absY, _boardStartY + TotalRows * _cellSize - bounds.Height));

                        sub.TranslationX = absX - bounds.X;
                        sub.TranslationY = absY - bounds.Y;
                        break;
                    }

                case GestureStatus.Completed:
                case GestureStatus.Canceled:
                    {
                        _lastTotal.Remove(sub);
                        var bounds = AbsoluteLayout.GetLayoutBounds(sub);
                        double finalX = bounds.X + sub.TranslationX;
                        double finalY = bounds.Y + sub.TranslationY;
                        sub.TranslationX = 0;
                        sub.TranslationY = 0;
                        AbsoluteLayout.SetLayoutBounds(sub, new Rect(finalX, finalY, bounds.Width, bounds.Height));
                        TrySnapToBoard(sub);
                        break;
                    }
            }
        }

        private void TrySnapToBoard(View sub)
        {
            var cur = AbsoluteLayout.GetLayoutBounds(sub);
            double cx = cur.X + cur.Width / 2;
            double cy = cur.Y + cur.Height / 2;

            bool overGameArea =
                cx >= 0 && cx <= _boardWidth &&
                cy >= _gameAreaTop && cy <= _gameAreaBottom;

            if (overGameArea)
            {
                int col = (int)Math.Floor(cur.X / _cellSize);
                int row = (int)Math.Floor((cur.Y - _gameAreaTop) / _cellSize);

                col = Math.Clamp(col, 0, Cols - 1);
                row = Math.Clamp(row, 0, GameRows - 1);

                double snapX = col * _cellSize;
                double snapY = _gameAreaTop + row * _cellSize;

                bool fits =
                    snapX + cur.Width <= _boardWidth + 0.5 &&
                    snapY + cur.Height <= _gameAreaBottom + 0.5;

                if (fits)
                {
                    AbsoluteLayout.SetLayoutBounds(sub, new Rect(snapX, snapY, cur.Width, cur.Height));
                    _playerOrigPos[sub] = new Point(snapX, snapY);
                    return;
                }
            }

            ReturnToOrigin(sub);
        }

        private void ReturnToOrigin(View sub)
        {
            if (_playerOrigPos.TryGetValue(sub, out var origin))
            {
                var b = AbsoluteLayout.GetLayoutBounds(sub);
                AbsoluteLayout.SetLayoutBounds(sub, new Rect(origin.X, origin.Y, b.Width, b.Height));
            }
        }

        private async void StartGame_Click(object sender, EventArgs e)
        {
            _game.SetupPlayers(_humanPlayer, _aiPlayerModel);

            bool allPlaced = PlacePlayerSubmarines();
            if (!allPlaced) return;

            PlaceAISubmarines();
            _game.StartGame();
            _phase = GamePhase.Playing;

            StartGameBtn.IsVisible = false;

            if (_isMulti)
            {
                bool myTurn = _firebase.IsPlayer1;
                UpdateStatusLabel(myTurn ? "���� �����" : $"��� {_opponentName}", myTurn ? "#009ADA" : "#AA3333");
                StartPolling();
            }
            else
            {
                UpdateStatusLabel("���� �����", "#009ADA");
            }

            ResetTimer();
        }

        private bool PlacePlayerSubmarines()
        {
            foreach (var (view, submarine) in _subViewToModel)
            {
                var bounds = AbsoluteLayout.GetLayoutBounds(view);
                double cx = bounds.X + bounds.Width / 2;
                double cy = bounds.Y + bounds.Height / 2;

                bool onBoard =
                    cx >= 0 && cx <= _boardWidth &&
                    cy >= _gameAreaTop && cy <= _gameAreaBottom;

                if (!onBoard)
                {
                    DisplayAlert("�����", "�� ����� �� �� ������� �� ����", "�����");
                    return false;
                }

                int col = (int)Math.Floor(bounds.X / _cellSize);
                int row = (int)Math.Floor((bounds.Y - _gameAreaTop) / _cellSize);

                col = Math.Clamp(col, 0, Cols - 1);
                row = Math.Clamp(row, 0, GameRows - 1);

                submarine.SetLocation(new GridLocation(row, col));
                bool placed = _game.PlaceSubmarine(_humanPlayer, submarine);

                if (!placed)
                {
                    DisplayAlert("�����", "��� ������ ������", "�����");
                    return false;
                }
            }
            return true;
        }

        private void PlaceAISubmarines()
        {
            var random = new Random();
            var aiFleet = new List<Submarine>
            {
                new Submarine(10, new GridLocation(0, 0), 4, Orientation.Horizontal),
                new Submarine(11, new GridLocation(0, 0), 3, Orientation.Horizontal),
                new Submarine(12, new GridLocation(0, 0), 2, Orientation.Horizontal),
                new Submarine(13, new GridLocation(0, 0), 3, Orientation.Vertical),
                new Submarine(14, new GridLocation(0, 0), 2, Orientation.Vertical),
            };

            foreach (var sub in aiFleet)
            {
                bool placed = false;
                int attempts = 0;
                while (!placed && attempts < 500)
                {
                    attempts++;
                    int row = random.Next(0, GameRows);
                    int col = random.Next(0, Cols);
                    var orientation = (Orientation)random.Next(0, 2);
                    sub.SetLocation(new GridLocation(row, col));
                    sub.SetOrientation(orientation);
                    placed = _game.PlaceSubmarine(_aiPlayerModel, sub);
                }
            }
        }

        private async void OnAICellTapped(View cell, int row, int col)
        {
            if (_phase != GamePhase.Playing) return;
            if (_game.CurrentPlayer != _humanPlayer) return;

            var aiBoard = _game.GetOpponentBoardPublic(_humanPlayer);
            if (!aiBoard.CanShootAt(row, col)) return;

            var result = _game.ProcessShot(new GridLocation(row, col));
            UpdateCellVisual(cell, result);

            string toastMsg = result switch
            {
                ShotResult.Miss => "�����",
                ShotResult.Hit => "����",
                ShotResult.Sunk => "����� �����",
                _ => ""
            };
            ShowToast(toastMsg, result);

            if (_isMulti)
                await _firebase.SendShotAsync(row, col, result.ToString());

            if (_game.Status == Game.GameStatus.Finished)
            {
                EndGame();
                return;
            }

            UpdateStatusLabel(_isGemini ? "Gemini ����... ??" : $"��� {_opponentName}", "#AA3333");
            ResetTimer();

            if (!_isMulti)
            {
                if (_isGemini)
                {
                    // ��� Gemini � async
                    await GeminiTurnAsync();
                }
                else
                {
                    Dispatcher.StartTimer(TimeSpan.FromMilliseconds(800), () =>
                    {
                        AITurn();
                        return false;
                    });
                }
            }
        }

        private void AITurn()
        {
            var playerBoard = _game.GetOpponentBoardPublic(_aiPlayerModel);
            var location = _ai.DecideNextShot(playerBoard);
            var result = _game.ProcessShot(location);

            _ai.ProcessShotResult(location, result);

            int gameRow = location.GetRow();
            int gameCol = location.GetColumn();

            MainThread.BeginInvokeOnMainThread(() =>
            {
                AddHitMarkerToPlayerBoard(gameRow, gameCol, result);

                if (result == ShotResult.Sunk)
                    RevealSunkPlayerSubmarine(playerBoard, gameRow, gameCol);

                string toastMsg = result switch
                {
                    ShotResult.Miss => "���� ����",
                    ShotResult.Hit => "���� ��� ��",
                    ShotResult.Sunk => "���� ����� �����",
                    _ => ""
                };
                ShowToast(toastMsg, result);

                if (_game.Status == Game.GameStatus.Finished)
                {
                    EndGame();
                    return;
                }

                UpdateStatusLabel("���� �����", "#009ADA");
                ResetTimer();
            });
        }

        /// <summary>
        /// ��� Gemini � ���� �� ��� ���� ����� �����.
        /// �� Gemini ���� � ���� ��������� ����� ������.
        /// </summary>
        private async Task GeminiTurnAsync()
        {
            var playerBoard = _game.GetOpponentBoardPublic(_aiPlayerModel);

            // ����� ��� ���� �-int[,]
            var boardState = new int[10, 10];
            for (int r = 0; r < 10; r++)
            {
                for (int c = 0; c < 10; c++)
                {
                    var cell = playerBoard.GetCell(r, c);
                    if (!cell.WasShot)
                        boardState[r, c] = 0; // �� ���
                    else if (!cell.IsHit)
                        boardState[r, c] = 1; // �����
                    else
                    {
                        // ���� �� ������ �����
                        int subId = cell.SubmarineId;
                        var subCell = playerBoard.GetCell(r, c);
                        boardState[r, c] = 2; // ����� (����� �-3 �� �����)
                    }
                }
            }

            // ��� ����� �-Gemini
            var shot = await _gemini.GetNextShotAsync(boardState);

            // �� Gemini ���� �� ����� �� ���� ��� ���� � ����� ���������
            if (shot == null || !playerBoard.CanShootAt(shot.Value.row, shot.Value.col))
            {
                AITurn(); // �����
                return;
            }

            var location = new GridLocation(shot.Value.row, shot.Value.col);
            var result = _game.ProcessShot(location);

            int gameRow = shot.Value.row;
            int gameCol = shot.Value.col;

            MainThread.BeginInvokeOnMainThread(() =>
            {
                AddHitMarkerToPlayerBoard(gameRow, gameCol, result);

                if (result == ShotResult.Sunk)
                    RevealSunkPlayerSubmarine(playerBoard, gameRow, gameCol);

                string toastMsg = result switch
                {
                    ShotResult.Miss => "Gemini ���� ??",
                    ShotResult.Hit => "Gemini ��� ��! ??",
                    ShotResult.Sunk => "Gemini ����� �����! ??",
                    _ => ""
                };
                ShowToast(toastMsg, result);

                if (_game.Status == Game.GameStatus.Finished)
                {
                    EndGame();
                    return;
                }

                UpdateStatusLabel("���� �����", "#009ADA");
                ResetTimer();
            });
        }

        private void StartPolling()
        {
            _pollCts = new CancellationTokenSource();
            var token = _pollCts.Token;

            Task.Run(async () =>
            {
                while (!token.IsCancellationRequested)
                {
                    await Task.Delay(2000, token);

                    var shot = await _firebase.GetLatestOpponentShotAsync(_knownOpponentShots);
                    if (shot != null)
                    {
                        _knownOpponentShots++;
                        MainThread.BeginInvokeOnMainThread(() => ApplyOpponentShot(shot));
                    }

                    var messages = await _firebase.GetChatMessagesAsync(_knownChatMessages);
                    if (messages.Any())
                    {
                        _knownChatMessages += messages.Count;
                        MainThread.BeginInvokeOnMainThread(async () =>
                        {
                            foreach (var msg in messages)
                                ChatMessages.Text += $"{msg.Sender}: {msg.Text}\n";

                            await ChatScrollView.ScrollToAsync(0, ChatMessages.Height, true);
                        });
                    }
                }
            }, token);
        }

        private void ApplyOpponentShot(MultiShot shot)
        {
            if (_phase != GamePhase.Playing) return;

            var result = shot.Result switch
            {
                "Hit" => ShotResult.Hit,
                "Sunk" => ShotResult.Sunk,
                _ => ShotResult.Miss
            };

            AddHitMarkerToPlayerBoard(shot.Row, shot.Col, result);

            var playerBoard = _game.GetOpponentBoardPublic(_aiPlayerModel);
            if (result == ShotResult.Sunk)
                RevealSunkPlayerSubmarine(playerBoard, shot.Row, shot.Col);

            string toastMsg = result switch
            {
                ShotResult.Miss => $"{_opponentName} ����",
                ShotResult.Hit => $"{_opponentName} ��� ��",
                ShotResult.Sunk => $"{_opponentName} ����� �����",
                _ => ""
            };
            ShowToast(toastMsg, result);

            _game.SwitchTurn();
            UpdateStatusLabel("���� �����", "#009ADA");
            ResetTimer();
        }

        private void AddHitMarkerToPlayerBoard(int gameRow, int gameCol, ShotResult result)
        {
            double markerSize = _cellSize * 0.7;
            double offset = _cellSize * 0.15;
            double x = gameCol * _cellSize + offset;
            double y = _gameAreaTop + gameRow * _cellSize + offset;

            var color = result switch
            {
                ShotResult.Miss => Color.FromArgb("#88AAAAAA"),
                ShotResult.Hit => Color.FromArgb("#DDFF6600"),
                ShotResult.Sunk => Color.FromArgb("#DDFF0000"),
                _ => Colors.Transparent
            };

            var marker = new BoxView
            {
                Color = color,
                WidthRequest = markerSize,
                HeightRequest = markerSize,
                CornerRadius = (float)(markerSize / 2),
                InputTransparent = true
            };

            AbsoluteLayout.SetLayoutBounds(marker, new Rect(x, y, markerSize, markerSize));
            PlayerArea.Children.Add(marker);
        }

        private void RevealSunkPlayerSubmarine(Board playerBoard, int hitRow, int hitCol)
        {
            int subId = playerBoard.GetSubmarineIdAt(hitRow, hitCol);
            if (subId == -1) return;

            var cells = playerBoard.GetSubmarineCells(subId);
            foreach (var (r, c) in cells)
            {
                if (_playerCellViews.TryGetValue((r, c), out var cellView))
                    cellView.BackgroundColor = Color.FromArgb("#88FF0000");
                AddHitMarkerToPlayerBoard(r, c, ShotResult.Sunk);
            }
        }

        private void UpdateCellVisual(View cell, ShotResult result)
        {
            if (cell is not Border border) return;
            border.BackgroundColor = result switch
            {
                ShotResult.Miss => Color.FromArgb("#555555"),
                ShotResult.Hit => Color.FromArgb("#FF6600"),
                ShotResult.Sunk => Color.FromArgb("#FF0000"),
                _ => border.BackgroundColor
            };
        }

        private async void ShowToast(string message, ShotResult result)
        {
            ToastLabel.Text = message;
            ToastFrame.BackgroundColor = result switch
            {
                ShotResult.Miss => Color.FromArgb("#CC333333"),
                ShotResult.Hit => Color.FromArgb("#CCAA4400"),
                ShotResult.Sunk => Color.FromArgb("#CCAA0000"),
                _ => Color.FromArgb("#CC000000")
            };

            ToastFrame.IsVisible = true;
            ToastFrame.Opacity = 1;
            await Task.Delay(3000);
            await ToastFrame.FadeTo(0, 500);
            ToastFrame.IsVisible = false;
            ToastFrame.Opacity = 1;
        }

        private async void EndGame()
        {
            _phase = GamePhase.Finished;
            _cts?.Cancel();
            _pollCts?.Cancel();

            bool playerWon = _game.Winner == _humanPlayer;
            double accuracy = _humanPlayer.GetCurrentAccuracy();
            int shots = _game.GetShotCount(_humanPlayer);

            bool newRecord = false;
            if (!_isGuest && _firebase.IsLoggedIn)
            {
                var (_, isNewRecord) = await _firebase.SaveGameResultAsync(playerWon, shots, accuracy);
                newRecord = isNewRecord;
                if (_isMulti)
                    await _firebase.FinishRoomAsync(playerWon);
            }

            await Navigation.PushAsync(new StatsPage(
                playerWon: playerWon,
                playerName: _humanPlayer.GetUserName(),
                playerShots: shots,
                playerAccuracy: accuracy,
                aiShots: _game.GetShotCount(_aiPlayerModel),
                aiAccuracy: _aiPlayerModel.GetCurrentAccuracy(),
                firebase: _firebase,
                isGuest: _isGuest,
                newRecord: newRecord,
                player: _humanPlayer
            ));
        }

        private void UpdateStatusLabel(string text, string colorHex)
        {
            StatusLabel.Text = text;
            StatusLabel.TextColor = Color.FromArgb(colorHex);
        }

        private void StartTimer()
        {
            _cts = new CancellationTokenSource();
            var token = _cts.Token;

            Dispatcher.StartTimer(TimeSpan.FromSeconds(1), () =>
            {
                if (token.IsCancellationRequested) return false;
                _timeLeft--;
                MainThread.BeginInvokeOnMainThread(() => TimerLabel.Text = _timeLeft.ToString());
                if (_timeLeft <= 0)
                {
                    MainThread.BeginInvokeOnMainThread(OnTimeExpired);
                    return false;
                }
                return true;
            });
        }

        private void OnTimeExpired()
        {
            if (_phase != GamePhase.Playing) return;

            if (_game.CurrentPlayer == _humanPlayer)
            {
                _game.SwitchTurn();
                UpdateStatusLabel(_isGemini ? "Gemini ����... ??" : $"���� ���� - ��� {_opponentName}", "#AA3333");
                ResetTimer();

                if (!_isMulti)
                {
                    if (_isGemini)
                    {
                        Task.Run(async () => await GeminiTurnAsync());
                    }
                    else
                    {
                        Dispatcher.StartTimer(TimeSpan.FromMilliseconds(800), () =>
                        {
                            AITurn();
                            return false;
                        });
                    }
                }
            }
            else
            {
                _game.SwitchTurn();
                UpdateStatusLabel("���� �����", "#009ADA");
                ResetTimer();
            }
        }

        private void ResetTimer()
        {
            _cts?.Cancel();
            _timeLeft = TurnSeconds;
            TimerLabel.Text = _timeLeft.ToString();
            StartTimer();
        }

        private void OnChatIconTapped(object sender, TappedEventArgs e)
            => ChatWindow.IsVisible = !ChatWindow.IsVisible;

        private async void SendMessage_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ChatEntry.Text)) return;

            string msg = ChatEntry.Text.Trim();
            ChatEntry.Text = string.Empty;
            ChatMessages.Text += $"���: {msg}\n";

            await ChatScrollView.ScrollToAsync(0, ChatMessages.Height, true);

            if (_isMulti)
                await _firebase.SendChatMessageAsync(msg);
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            _cts?.Cancel();
            _pollCts?.Cancel();
        }
    }
}